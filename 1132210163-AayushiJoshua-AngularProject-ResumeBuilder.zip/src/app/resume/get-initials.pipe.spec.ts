import { GetInitialsPipe } from './get-initials.pipe';

describe('GetInitialsPipe', () => {
  it('create an instance', () => {
    const pipe = new GetInitialsPipe();
    expect(pipe).toBeTruthy();
  });
});
