export class project{
    title!:string;
    desc!:string;
}