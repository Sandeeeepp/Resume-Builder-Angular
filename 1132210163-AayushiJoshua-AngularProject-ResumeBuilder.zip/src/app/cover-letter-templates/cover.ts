export class Cover {
    id!:string;
    cname!: string;
    cemail!:string;
    phoneno!: string;
    recruitertitle!: string;
    recruitername!: string;
    companyname!: string;
    companyaddress!: string;
    city!: string;
    state!: string;
    postalcode!: string;
    jobtitle!: string;
}