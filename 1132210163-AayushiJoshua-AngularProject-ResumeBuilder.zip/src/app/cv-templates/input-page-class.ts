export class details {
  fname = '';
  lname = '';
  mname = '';
  email = '';
  phoneno = '';
  state = '';
  city = '';
  linkWebsite = new Array();
  links = new Array();

  skills = new Array();
  objective = '';

  degree = new Array();
  school = new Array();
  cities = new Array();
  educationStartDate = new Array();
  educationEndDate = new Array();

  projectTitle = new Array();
  projectDescription = new Array();
  projectStartDate = new Array();
  projectEndDate = new Array();

  certificateTitle = new Array();

  internshipCompanyName = new Array();
  internshipDesignation = new Array();
  internshipDescription = new Array();

  jobCompanyName = new Array();
  jobRole = new Array();
  jobDescription = new Array();
}
