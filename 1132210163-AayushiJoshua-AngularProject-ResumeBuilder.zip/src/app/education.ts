export class education{
    
    course!:string;
    school!:string;
    city!:string;
    sdate!:string;
    edate!:string;
}