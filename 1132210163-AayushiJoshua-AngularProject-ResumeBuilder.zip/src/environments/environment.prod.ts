export const environment = {
  firebase: {
    projectId: 'assignment2-ac9d6',
    appId: '1:512702224821:web:7fe2b9e30357e3b62c21fc',
    storageBucket: 'assignment2-ac9d6.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDyMIONdsDs3BZF3XXR9o2fElmDH5E5HZ8',
    authDomain: 'assignment2-ac9d6.firebaseapp.com',
    messagingSenderId: '512702224821',
    measurementId: 'G-4PYGYN8YPZ',
  },
  production: true
};
