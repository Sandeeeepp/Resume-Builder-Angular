// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  firebase: {
    projectId: 'assignment2-ac9d6',
    appId: '1:512702224821:web:7fe2b9e30357e3b62c21fc',
    storageBucket: 'assignment2-ac9d6.appspot.com',
    locationId: 'us-central',
    apiKey: 'AIzaSyDyMIONdsDs3BZF3XXR9o2fElmDH5E5HZ8',
    authDomain: 'assignment2-ac9d6.firebaseapp.com',
    messagingSenderId: '512702224821',
    measurementId: 'G-4PYGYN8YPZ',
  },
  production: false
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
